#include "stdafx.h"

RoninSecure pRoninSecure;