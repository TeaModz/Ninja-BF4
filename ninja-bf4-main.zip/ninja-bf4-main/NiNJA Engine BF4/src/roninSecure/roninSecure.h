#pragma once

class RoninSecure {
public:
	Module pModule;
	Runtime pRuntime;
	XboxDebugManager pXboxDebugManager;
};

extern RoninSecure pRoninSecure;