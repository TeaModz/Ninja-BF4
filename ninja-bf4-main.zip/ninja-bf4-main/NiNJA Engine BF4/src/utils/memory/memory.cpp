#include "stdafx.h"

Memory pMemory;